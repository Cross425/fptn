# README.md

Requires Python 3.6+ and macOS host with pkgbuild and productbuild available

pip3 install macos-pkg-builder

pip install clang-tidy
pip install clang-format
pip install cmake-format
brew install cppcheck