/*=============================================================================
Copyright (c) 2024-2025 Stas Skokov

Distributed under the MIT License (https://opensource.org/licenses/MIT)
=============================================================================*/

#pragma once

#include "filter/filters/base_filter.h"

namespace fptn::filter {
class BitTorrent : public BaseFilter {
 public:
  BitTorrent() = default;
  ~BitTorrent() override = default;
  fptn::common::network::IPPacketPtr apply(
      fptn::common::network::IPPacketPtr packet) const override;
};
}  // namespace fptn::filter
